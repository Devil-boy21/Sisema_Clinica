<?php session_start(); //INICIA LA SESION
if(empty($_SESSION['acceso']) || $_SESSION['acceso'] == '') //VALIDA QUE EXISTA UNA SESION, EN CASO DE QUE NO SE HAYA LOGUEADO NINGUN USUARIO, VA REDIRIGIR AL USUARIO A LA PAGINA DE INICIO DE SESION
{
   header("Location: clinica-login.php"); 
   die();
}
?>
<?php /*VALIDA EL USUARIO QUE INICIO LA SESION SI ES ADMINISTRADOR O USUARIO, MOSTRANDO EL NAVBAR CORRESPONDIENTE*/
if($_SESSION['privilegios'] == 0)
{
   include 'header-admin.php'; //SE MUESTRA EL NAVBAR CON LAS OPCIONES DEL ADMINISTRADOR
}
else
{
   include 'header-user.php'; //SE MUESTRA EL NAVBAR CON LAS OPCIONES DEL USUARIO
}
?>
<?php include('connect.php');?> <!--CONEXION A LA BASE DE DATOS-->

<!DOCTYPE html>
<html lang="es">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="shortcut icon" href="medicina.jpg"/>
   <link rel="stylesheet" href="clinica-appointment.css">
  <script
   src="https://code.jquery.com/jquery-3.6.0.min.js"
   integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4="
   crossorigin="anonymous"></script>
   <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>
   <?php
   if($_SESSION['privilegios'] == 0) //SI EL USUARIO QUE INICIO SESION ES ADMINISTRADOR, MUESTRA EL MENSAJE CORRESPONDIENTE EN EL DIV
   {
      echo '<div class="container">Nombre: '. $_SESSION['nombre'] .' Usuario: ' . $_SESSION['usuario'] . '
      <div class="overlay">
         <div class="textOverlay">Tipo de cuenta: administardor</div>
         </div>
      </div>';
   }
   else // EN CAMBIO SI EL USUARIO QUE INICIO SESION ES USUARIO, MUESTRA EL MENSAJE CORRESPONDIENTE EN EL DIV
   {
      echo '<div class="container">Nombre: '. $_SESSION['nombre'] .' Usuario: ' . $_SESSION['usuario'] . '
      <div class="overlay">
         <div class="textOverlay">Tipo de cuenta: usuario</div>
         </div>
      </div>';
   }
   ?>
   <img src="logo_clinica.png" alt="Clínica Encinas"><br><br>
   <div class="testbox">
      <form method="post">
         <div class="banner">
        <h1>Eliminar Médico</h1>
         </div>
         <div class="colums">
            <div class="item">
               <label for="fname">Ingrese el ID del médico a eliminar<span>*</span></label>
               <input id="fname" type="text" name="dato_id"  required/>
            </div>
            <div class="btn-block2">
               <button type="submit" class="hvr-pulse-shrink" name="deleteButton">Eliminar</button>
            </div>
         </form>
          <?php
         if(array_key_exists('deleteButton', $_POST)) 
         {
         $dato_id = $_POST['dato_id'];

         $post = (isset($_POST['dato_id']) && !empty($_POST['dato_id']));

         if($post)
         {
            $resultado = $connect->query("SELECT * FROM medico where id = $dato_id");
            if($fila = mysqli_fetch_array($resultado))
            {
               if($fila['id'] == $dato_id && $fila['eliminado'] == 1)
               {
                  echo "<script> swal.fire({
                  icon: 'error',
                  title: 'Error!',
                  text: 'El médico no se encuentra en el sistema',
                  showConfirmButton: false,
                  position: 'center',
                  toast: true,
                  allowOutsideClick: false,
                  allowEnterKey: true,
                  timer: 3500
                  });</script>";
                  
               }
               else if($fila['id'] == $dato_id && $fila['eliminado'] == 0)
               {
                  $connect->query("UPDATE medico SET eliminado = 1 WHERE id = $dato_id");
                  echo "<script> swal.fire({
                  icon: 'success',
                  title: '¡Confirmación!',
                  text: 'El médico fue eliminado correctamente',
                  showConfirmButton: false,
                  position: 'center',
                  toast: true,
                  allowOutsideClick: false,
                  allowEnterKey: true,
                  timer: 3500
                  });</script>";
               }
            }
            else
               {
                 echo "<script> swal.fire({
                  icon: 'error',
                  title: '¡Error!',
                  text: 'El médico no se encuentra en el sistema',
                  position: 'center',
                  toast: true,
                  allowOutsideClick: false,
                  allowEnterKey: true,
                  confirmButtonText: 'Aceptar',
                  confirmButtonColor: '#9ca683',
                  type: 'error',
                  });</script>";
               }
         }
      }
      ?>
      </div>

      
    <footer>
      
      <!--Redes sociales-->
      <div class="rs">
            <!--Hipervinculo que nos lleva a la página oficial de facebook-->
            <br>
            <br>
            <a href="https://www.facebook.com/">
                <img src="Redes Sociales/facebook.png" style="width:30px;height:30px;">
            </a>
            <!--Hipervinculo que nos lleva a la página oficial de Instagram-->
            <a href="https://www.instagram.com/">
                <img src="Redes Sociales/instagram.png" style="width:30px;height:30px;">
            </a>
            <!--Hipervinculo que nos lleva a la página oficial de twitter-->
            <a href="https://twitter.com/?lang=es">
                <img src="Redes Sociales/twitter.png" style="width:30px;height:30px;">
            </a>
            <!--Hipervinculo que nos lleva a la página oficial de You tube-->
            <a href="https://www.youtube.com/">
                <img src="Redes Sociales/youtube.png" style="width:33px;height:30px;">
            </a>
            <br>
            <br>
            <!---Licencia Creative Commons--->
            <a rel="license" href="http://creativecommons.org/licenses/by-nc-sa/4.0/"><img alt="Licencia de Creative Commons" style="border-width:0" src="https://i.creativecommons.org/l/by-nc-sa/4.0/88x31.png" /></a><br />Este obra está bajo una <a rel="license" href="http://creativecommons.org/licenses/by-nc-sa/4.0/">licencia de Creative Commons Reconocimiento-NoComercial-CompartirIgual 4.0 Internacional</a>.
        </div>
    </footer>
   </body>
</html>